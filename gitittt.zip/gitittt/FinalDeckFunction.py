def create_new_deck(decknumber,dictforcards):
    decknumber = decknumber

    listofsuites = ['S' , 'H' , 'D' , 'C']
    finalcardlist = []
    for j in listofsuites:
        cardvalues = [str(decknumber)+ j + str(i) for i in range(1, 11)]
        cardvalues.append(str(decknumber)+ j + 'Jack')
        cardvalues.append(str(decknumber)+ j + 'Queen')
        cardvalues.append(str(decknumber)+ j + 'King')
        cardvalues.append(str(decknumber)+ j + 'Ace')
        for k in cardvalues:
            finalcardlist.append(k)

        pointcount = 1
        whilecount = 1
        for i in finalcardlist:
            if pointcount > 10:
                while whilecount < 5:
                    dictforcards[i] = pointcount -1
                    whilecount += 1
                    if whilecount == 5:
                        dictforcards[i] = pointcount
                        whilecount = 1
                        pointcount = 1
                    break
            else:
                dictforcards[i] = pointcount
                pointcount += 1
    return dictforcards
