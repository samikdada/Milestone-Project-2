class Dealer:

    def __init__(self):
        self.name = 'Dealer'
        self.currentcards = []
        self.currenttotal = 0
