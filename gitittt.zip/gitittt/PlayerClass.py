class Player():

    def __init__(self, name, bet):
        self.name = name
        self.bet = bet
        self.currenttotal = 0
        self.currentbalance = bet
        self.currentcards = []
