import os
from FinalDeckFunction import *
from PlayerClass import *
import random
from DealerClass import *

os.system('cls' if os.name == 'nt' else 'clear')
namesofplayers = {}
inputnumberofdecks = int(input('How many decks you want to include?\n'))
numberofplayers = int(input('How many players?\n'))
countofplayers = 1
countofdecks = 1
dictforcards = {}

def assign_card(nameofplayer):
    currentcard = random.choice(list(dictforcards.keys()))
    nameofplayer.currentcards.append(currentcard)
    get_total(nameofplayer,currentcard)

def get_total(nameofplayer,currentcard):
    nameofplayer.currenttotal += dictforcards[currentcard]
    del dictforcards[currentcard]

def Create_New_Player(name, bet):
    name = Player(name, bet)
    return name



while countofdecks <= inputnumberofdecks:
    dictforcards = create_new_deck(countofdecks,dictforcards)
    countofdecks += 1

####################################################################################################################
#For the number of players, ask the user for the name of those players
####################################################################################################################

while countofplayers <= numberofplayers:
    os.system('cls' if os.name == 'nt' else 'clear')
    name = input('Enter the name of player ' + str(countofplayers) + ': ')
    betcount = True
    while betcount:
        try:
            bet = int(input('Enter the bet amount ' + name + ': '))

        except:
            print('The entered value is not a number ' + name +'. Please try again.')
            continue
        else:
            betcount = False

    namesofplayers[countofplayers] = Create_New_Player(name,bet)
    countofplayers += 1

####################################################################################################################
os.system('cls' if os.name == 'nt' else 'clear')
for i in range(1,numberofplayers+1):
    assign_card(namesofplayers[i])
    #namesofplayers[i].currenttotal = get_total(namesofplayers[i].currentcards )
    assign_card(namesofplayers[i])
    assign_card(namesofplayers[i])
    #namesofplayers[i].currentcards.append(random.choice(list(dictforcards.keys())))
    #namesofplayers[i].currenttotal = get_total(namesofplayers[i].currentcards )
    print('Player ' + namesofplayers[i].name + ' has placed a bet of ' + str(namesofplayers[i].bet))
    print('Player ' + namesofplayers[i].name + ' has card ' + str(namesofplayers[i].currentcards))
    print('Player ' + namesofplayers[i].name + ' has a total of ' + str(namesofplayers[i].currenttotal))




